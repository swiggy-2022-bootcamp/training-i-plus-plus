package add

func Add(x, y int) int {
	return x + y
}

func Sub(x, y int) int {
	return x + y
}
