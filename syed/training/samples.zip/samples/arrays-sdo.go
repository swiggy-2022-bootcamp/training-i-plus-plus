package main

import "fmt"

func main(){
	numbersArray := [5]int{20,40,60,80,100}
	stringArray := [4]string{"first","second","third","fourth"}

	fmt.Println("Integer array is : " ,numbersArray)
	fmt.Println("String Array is : " , stringArray)
}