package main

import "fmt"

func main(){
	fmt.Println("Welome to GoLang() !!! ")
}