package main

import "fmt"

var flag1,flag2,flag3 bool

func main(){
	var x int
	fmt.Println(x,flag1,flag2,flag3)
}
